import React from "react";
import { View, Button, Text, StyleSheet } from "react-native";

export default function LoginScreen({ navigation }) {
  return (
    <View style={styles.container}>
      <Text style={styles.title}>MediX - اختر نوع الدخول</Text>
      <Button title="👤 مريض" onPress={() => navigation.navigate("Patient")} />
      <Button title="🧑‍⚕️ طبيب" onPress={() => navigation.navigate("Doctor")} />
      <Button title="🏥 صيدلي" onPress={() => navigation.navigate("Pharmacy")} />
      <Button title="🚑 إسعاف" onPress={() => navigation.navigate("Ambulance")} />
      <Button title="🏛️ وزارة الصحة" onPress={() => navigation.navigate("AdminLogin")} />
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, justifyContent: "center", alignItems: "center" },
  title: { fontSize: 20, marginBottom: 20 }
});