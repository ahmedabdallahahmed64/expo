import React from "react";
import { View, Text, StyleSheet } from "react-native";

export default function PatientScreen() {
  return (
    <View style={styles.container}>
      <Text style={styles.text}>مرحباً بك أيها المريض 👤</Text>
      <Text>يمكنك البحث عن الأطباء، الصيدليات، أو طلب إسعاف.</Text>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, justifyContent: "center", alignItems: "center" },
  text: { fontSize: 18, marginBottom: 10 }
});