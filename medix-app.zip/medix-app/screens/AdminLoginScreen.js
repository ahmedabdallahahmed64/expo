import React from "react";
import { View, Text, Button, StyleSheet } from "react-native";

export default function AdminLoginScreen({ navigation }) {
  return (
    <View style={styles.container}>
      <Text style={styles.text}>تسجيل دخول وزارة الصحة 🏛️</Text>
      <Button title="تسجيل الدخول" onPress={() => navigation.navigate("Admin")} />
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, justifyContent: "center", alignItems: "center" },
  text: { fontSize: 18, marginBottom: 10 }
});