import React from "react";
import { View, Text, StyleSheet } from "react-native";

export default function AmbulanceScreen() {
  return (
    <View style={styles.container}>
      <Text style={styles.text}>صفحة الإسعاف 🚑</Text>
      <Text>سجّل عربتك وحدد موقعك لتلقي طلبات الطوارئ.</Text>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, justifyContent: "center", alignItems: "center" },
  text: { fontSize: 18, marginBottom: 10 }
});