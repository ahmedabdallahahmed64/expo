import React from "react";
import { NavigationContainer } from "@react-navigation/native";
import { createNativeStackNavigator } from "@react-navigation/native-stack";

import LoginScreen from "./screens/LoginScreen";
import PatientScreen from "./screens/PatientScreen";
import DoctorScreen from "./screens/DoctorScreen";
import PharmacyScreen from "./screens/PharmacyScreen";
import AmbulanceScreen from "./screens/AmbulanceScreen";
import AdminLoginScreen from "./screens/AdminLoginScreen";
import AdminMain from "./screens/AdminMain";

const Stack = createNativeStackNavigator();

export default function App() {
  return (
    <NavigationContainer>
      <Stack.Navigator screenOptions={{ headerShown: true }}>
        <Stack.Screen name="Login" component={LoginScreen} options={{ title: "MediX - تسجيل الدخول" }} />
        <Stack.Screen name="Patient" component={PatientScreen} options={{ title: "المريض" }} />
        <Stack.Screen name="Doctor" component={DoctorScreen} options={{ title: "الطبيب" }} />
        <Stack.Screen name="Pharmacy" component={PharmacyScreen} options={{ title: "الصيدلية" }} />
        <Stack.Screen name="Ambulance" component={AmbulanceScreen} options={{ title: "الإسعاف" }} />
        <Stack.Screen name="AdminLogin" component={AdminLoginScreen} options={{ title: "وزارة الصحة - تسجيل الدخول" }} />
        <Stack.Screen name="Admin" component={AdminMain} options={{ title: "لوحة الوزارة" }} />
      </Stack.Navigator>
    </NavigationContainer>
  );
}